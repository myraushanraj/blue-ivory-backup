var mongoose = require('mongoose');
const ObjectId = mongoose.Schema.Types.ObjectId;

// define the schema for Join Table
var TransactionHistorySchema = new mongoose.Schema({

    "transaction_id" : {
        type : String,
    },

    "paymentgatewaytransaction_id" : {
        type : String,
    },

    "status": {
        type: String
    },

    "user_id" : {
        type : ObjectId,
        ref: 'User'
    },
    
    "actualamount" : {
        type : Number,
    },

    "amount" : {
        type : Number,
    },
    
    "tdsdeduction" : {
        type : Number,
        default : 0
    },
        
    "type" : {
        type : String,
    },
    
    "tds" : {
        type: Boolean,
        default: false
    },

    "promocode": {
        type: Boolean,
        default: false
    },

    "promocode_id" : {
        type: ObjectId,
        ref: 'PromoCode',
        default: null
    },

    "instantbonus": {
        type: Number,
        default : 0
    },

    "lockedbonus" : {
        type: Number,
        default: 0
    },

    "withdrawaltype" : {
        type : String,
    },

    "created": {
        type: Number,
        default: Date.now()
    },
    withdrawal_details:{
        status:{
            type:String,
            default:"initiated"
          },
          transaction_id:{
              type:String,
              default:""
          },
          cashfree_reference_id:{
              type:String,
              default:""
          },
          cashfree_utr:{
              type:String,
              default:""
          },
          notes:{
              type:String,
              default:""
          },
          transfer_time:{
              type:Number,
              default:""
          }
    }

},
    {
        timestamps: true
    });

module.exports = mongoose.model('TransactionHistory', TransactionHistorySchema);