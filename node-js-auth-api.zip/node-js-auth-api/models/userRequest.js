var mongoose = require('mongoose');
const ObjectId = mongoose.Schema.Types.ObjectId;
const User = require('./user')

// define the schema for User Email Request
var UserRequest = new mongoose.Schema({
    "type" : {
        type : String,
    },
    "descriptions" : {
        type : String,
    },
    "created": {
        type: Number,
        default: Date.now()
    },
    "users" : {
        type : ObjectId,
        ref: 'User'
    },
    "status" : {
        type : String,
        default:"unapproved"
    },
},
    {
        timestamps: true
    });

module.exports = mongoose.model('UserRequest', UserRequest)
