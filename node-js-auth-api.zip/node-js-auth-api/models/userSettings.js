var mongoose = require('mongoose');
const ObjectId = mongoose.Schema.Types.ObjectId;
const User = require('./user')
const uuidv1 = require('uuid/v1');

// define the schema for User setting
var UserSettingsSchema = new mongoose.Schema({

    "settings_id" : {
        type : String,
        default : uuidv1()
    },

    "user_id" : {
        type: ObjectId,
		ref: 'User'
    },

    "ingamesettings" : {
        "tournamentlobby" : {
            type : Boolean,
            default : false
        },
        "automuckcards" : {
            type : Boolean,
            default : false
        },

        "customizetable" : {
            //deck setting
            "deckfrontindex" : {
                type : Number,
                default : 0
            },
            "deckbackindex" : {
                type : Number,
                default : 0
            },
            //table setting
            "tablefeltcolor" : {
                type : String,
                default : "Tables/Felts/Basic/FeltPackBasic1/Felt"
            },
            "tablefeltcolorpremium" : {
                type : String,
                default : "Tables/Felts/Premium/FeltPackPremium1/felt"
            },
            "tablefeltpattern" : {
                type : String,
                default : "Tables/FeltPatterns/FeltPattern1/pattern"
            },
            // table background setting
            "tablebackgroundindex" : {
                type : Number,
                default : 0
            }
        },
    },

    "buyinpreference" : {
        "autobuyin" : {
            "autobuyinstatus" : {
                type : Boolean,
                default : false
            },
            "autobuyinamount" : {
                type : Number,
                default : 0
            }
        },

        "autotopup" : {
            "autotopupstatus" : {
                type : Boolean,
                default : false
            },
            "minthreshold" : {
                type : Number,
                default : 0
            }
        },
    },

    "audiosettings" : {
        "muteall" : {
            type : Boolean,
            default : false
        },
        "tablesoundeffect" : {
            type : Boolean,
            default : false
        },
        "notification" : {
            type : Boolean,
            default : false
        }
    },

    "handhistorysettings" : {
        "savehandhistory" : {
            type : Boolean,
            default : true
        },
        "saveduration" : {
            type : Number,
            default : 30
        }
    },

    "responsiblegaming" : {

        //weekly deposit limit
        "weeklydeposit" : {
            "weeklydepositlimitstatus" : {
                type : Boolean,
                default : false
            },
            "weeklydepositlimit" : {
                type : Number,
                default : 0
            },
            "blockdepositability" : {
                type : Boolean,
                default : false
            },
            "weeklydepositlimitsetdate" : {
                type : Number,
                default : 0
            },
            "depositlimitsetdate" : {
                type : Number,
                default : 0
            }
        },

        //self-exclution
        "selfexclusion" : {
            "selfexclusionstatus" : {
                type : Boolean,
                default : false
            },
            "selfexclusionduration" : {
                type : Number,
                default : 0
            },
            "selfexclusionsetdate" : {
                type : Number,
                default : 0
            },
            "selectedindex" : {
                type : Number,
                default : null
            }
        },

        //table timit
        "tablelimit" : {
            "tablelimitstatus" : {
                type : Boolean,
                default : false
            },
            "tablelimitsb" : {
                type : Number,
                default : 0
            },
            "tablelimitbb" : {
                type : Number,
                default  :0
            },
            "selectedindex" : {
                type : Number,
                default : null
            }
        }
    }
},
  {
      timestamps: true
  });

module.exports = mongoose.model('UserSettings', UserSettingsSchema);