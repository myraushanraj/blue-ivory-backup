var mongoose = require('mongoose');
const ObjectId = mongoose.Schema.Types.ObjectId;
const PromoCode = require('./promoCode')

// define the schema for usedPromo
var UsedPromoCodeSchema = new mongoose.Schema({
        "usedpromocode_id" : {
            type : String,
        },

        "user_id" : {
            type : ObjectId,
            ref: 'User'
        },

        "usedpromocode" : {
            type : ObjectId,
            ref: 'PromoCode'
        },

        "created": {
            type: Number,
            default: Date.now()
        }
    },
        {
            timestamps: true
        }
    );

module.exports = mongoose.model('UsedPromoCode', UsedPromoCodeSchema);