var mongoose = require('mongoose');
const ObjectId = mongoose.Schema.Types.ObjectId;
const User = require('./user')

// define the schema for userwallet
var WalletSchema = new mongoose.Schema({

    "user_id" : {
        type: ObjectId,
        ref: 'User'
    },
    
    "firsttimedeposit": {
        type: Boolean,
        default: true
    },
    "totalbalance": {
        type: Number,
        default: 0
    },
    "inplaybalance": {
        type: Number,
        default: 0
    },
    "lockedbonus": {
        type: Number,
        default: 0
    },
    "lockedamount": {
        type: Number,
        default: 0
    },
    "instantbonus": {
        type: Number,
        default: 0
    },
    "withdrawable": {
        type: Number,
        default: 0
    },
    "fpp": {
        type: Number,
        default: 0
    },
    
    "availablebalance": {
        type: Number,
        default: 0
    }, 
    "transactionlimit": {
        type: Number,
        default: 100000
    },
    
    "availablelimit": {
        type: Number,
        default: 100000
    }
},
    {
        timestamps: true
    });

module.exports = mongoose.model('Wallet', WalletSchema);