var mongoose = require('mongoose');

const ObjectId = mongoose.Schema.Types.ObjectId;


// define the schema for user model
var UserLastLoginSchema = new mongoose.Schema({

	ip_address: {
		type: String,
		index: true
    },
    login_time:{
        type:Number,
        index:true
    },
    user_id : {
        type: ObjectId,
        ref: 'User'
    },
    login_via:{
        type:String,
        default:"N/A"
    }
},{
    timestamps: true
    
	});






module.exports = mongoose.model('UserLastLogin', UserLastLoginSchema);