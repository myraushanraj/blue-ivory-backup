const express = require('express');
const router = express.Router();
const auth = require("../controllers/authController");
const isAuthenticated = require('../middlewares/authorization');

//User Register
router.post('/register', auth.register);

//User signin
router.post('/signin', auth.signin);

//Google Login
router.post('/google-login', auth.googleSignin);

//Facebook Login
router.post('/facebook-login', auth.facebookSign);

//Forgot Password
router.post('/forgot-password', auth.forgotPassword);

//Verify Forgot Password
router.post('/verify-forgot-password', auth.verifyForgotPassword);

//Change Password
router.post('/change-password', isAuthenticated, auth.changePassword);

//Email Verification
router.post('/email-verification', auth.emailVerfication);

//Send Text Message
router.post('/send-text-message', auth.sendTextMessage);




module.exports = router;
