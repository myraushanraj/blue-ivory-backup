const { OAuth2Client } = require('google-auth-library');
const client = new OAuth2Client("739472579341-fas37tg12pegg1l1hpa7timu0pus2ntt.apps.googleusercontent.com");
var User = require('../../models/user');
const fetch = require('node-fetch');
var mailgun = require('mailgun-js')({ apiKey: process.env.mailgunApIKey, domain: process.env.mailgunDomain });
const Nexmo = require('nexmo');

module.exports = {

    //Verify Google Access Token
    varifyGoogleToken: (req, res) => {
        var token = req.body.token;
        async function verify() {
            const ticket = await client.verifyIdToken({
                idToken: token
            });
            const payload = ticket.getPayload();
            const userid = payload['sub'];
            return payload;
        }
        return verify().catch(console.error);
    },

    //Verify Facebook Access Token
    verifyFacebookToken: (accessToken) => {
        return new Promise(function (resolve, reject) {
            fetch(`https://graph.facebook.com/me?fields=id,name,email,picture.type(large)&access_token=${accessToken}`)
                .then(res => res.json())
                .then(json => resolve(json));
        })

    },

    //Get User By Email
    checkUserByEmail: (email) => {
        return new Promise(function (resolve, reject) {
            User.findOne({ useremail: email }).then((data) => {
                resolve(data)
            })
        })

    },

    //Send Email To User
    sendEmail: (mailOptions) => {
        return new Promise((resolve, reject) => {
            mailgun.messages().send(mailOptions, function (error, body) {
                if (error) {
                    reject("Email not sent");
                } else if (body.message === "Queued. Thank you.") {
                    resolve("Email Sent Successfully")

                } else {
                    console.log("Email Sent TO User");
                }
            });
        })
    },

    //Send Text Message To User
    sendTextMessage: (to, text) => {
        return new Promise((resolve, reject) => {
            const nexmo = new Nexmo({
                apiKey: 'b9d45235',
                apiSecret: 'WUHPf43u7gd1gXyZ',
            });


            nexmo.message.sendSms("IGAMIO", to, text, (err, textMessageStatus) => {
                if (err)
                    console.log(err);
                resolve(textMessageStatus);
            });

        })
    }

}