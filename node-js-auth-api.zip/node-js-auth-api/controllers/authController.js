var User = require('../models/user');
const uuidv1 = require('uuid/v1');
var randomstring = require('randomstring');
var Async = require("async");
const requestIp = require('request-ip');
var mongoose = require('mongoose');
var UserLastLogin = require('../models/user_last_login');
const jwt = require('jsonwebtoken');
var moment = require('moment');
var util = require("./common/helper");
var mailgun = require('mailgun-js')({ apiKey: process.env.mailgunApIKey, domain: process.env.mailgunDomain });




module.exports = {
  // User Register
  register: (req, res) => {
    var UUID = uuidv1();

    try {
      req.checkBody({
        'name': {
          notEmpty: true,
          isLength: {
            options: [{ min: 2, max: 25 }],
            errorMessage: 'Name too short, must be of atleast 2 and less than 25'
          },
          errorMessage: 'Please enter your name'
        },
        'username': {
          notEmpty: true,
          isLength: {
            options: [{ min: 5, max: 13 }],
            errorMessage: 'Username too short, must be of atleast 5 and less than 13'
          },
          errorMessage: 'Please enter your username'
        },
        'useremail': {
          notEmpty: true,
          errorMessage: 'Please enter your email'
        },
        'mobilenumber': {
          notEmpty: true,
          isNumeric: {
            errorMessage: 'Entered number must be numeric'
          },
          isLength: {
            options: [{ min: 10, max: 10 }],
            errorMessage: 'Please enter a valid phone number'
          },
          errorMessage: 'Please enter your phone number'
        },
        'password': {
          notEmpty: true,
          errorMessage: 'Please enter password ',
          isLength: {
            options: [{ min: 6, max: 20 }],
            errorMessage: 'password length must be greater than 6'
          }
        },
        'confirmpassword': {
          notEmpty: true,
          errorMessage: 'Please enter confirm password'
        }
      });

      const errors = req.validationErrors();
      if (errors) {
        var errorsMessage = [];
        errors.forEach(function (err) {
          errorsMessage.push(err.msg);
        });

        res.json({
          'status': 'error',
          'msg': errorsMessage[0]
        });
      } else {

        if (req.body.password === req.body.confirmpassword) {
          User.findOne({ $or: [{ 'useremail': req.body.useremail.toLowerCase() }, { 'username': req.body.username.toLowerCase() }] }, (err, user) => {
            if (err) {
              res.json({
                'status': 'error',
                'msg': err
              });
            }
            if (user !== null) {
              res.json({
                'status': 'error',
                'msg': 'user already registered'
              });
            } else {
              var verifyemailtoken = randomstring.generate(64);
              var verifyemailtokenexpiry = Date.now() + 1800000;       //30 minutes
              var register = new User({
                'user_id': UUID,
                'name': req.body.name.toLowerCase(),
                'displayname': req.body.name,
                'username': req.body.username.toLowerCase(),
                'displayusername': req.body.username,
                'useremail': req.body.useremail.toLowerCase(),
                'verifyemailtoken': verifyemailtoken,
                'verifyemailtokenexpiry': verifyemailtokenexpiry,
                'mobilenumber': req.body.mobilenumber,
                'password': req.body.password,
                'created': Date.now()
              });

              register.save(async (err, user) => {
                if (err) {
                  res.json({
                    'status': 'error',
                    'msg': 'error encountered'
                  });
                } else {
                  //End Email Verification to user
                  var mailOptions = {
                    from: 'IGAMIO <me@samples.mailgun.org>',
                    to: req.body.useremail,
                    subject: 'IGAMIO Account Confirmation ',
                    html: `
                                    <body style="    margin: 0px auto;
                                    background: #f0f0f0;
                                    padding: 100px 0px;">
                                    <div style="border:none;margin:50px auto;width:500px;background:white">
                                    <h2 style="text-align:center;background:blue;color:white;padding: 10px;">IGAMIO</h2>
                                        <h3 style="text-align:center">Hello ${user.username}, We're glad you're here!</h3>
                                       <p>&nbsp;</p>
                                          <p style="text-align:center">  <a style="    color: #fff;
                                          background: #00bcd4;
                                          padding: 5px;
                                          text-align: center;
                                          margin: auto;
                                          padding: 13px;
                                          font-size: 15px;
                                          text-decoration: none;
                                          font-weight: 600;" title="Confirm Your Email Address"  href='${process.env.APP_DOMAIN}/verifyforgotpasswordlink/${user.verifyemailtoken}'>Confirm Your Email Address  </a>
                                        <p>&nbsp;</p>
                                        <p style="color:gray;text-align:center">We just want to confirm you're you.</p>
                                        <p style="color:gray;text-align:center">If you didn't create a IGAMIO account, just delete this email and everything will go back to the way it was.</p>

                                        </div>
                                            </body>      
                            `
                  };
                  var emailResponse = await util.sendEmail(mailOptions);
                  console.log("Email Response", emailResponse);
                  res.json({
                    'status': 'success',
                    'msg': 'Registered Successfully'
                  });
                }
              });
            }
          });
        } else {
          res.json({
            'status': 'error',
            'msg': 'password and confirm passowrd should be same!'
          });
        }
      }
    } catch (e) {
      res.json({
        'status': 'error',
        'msg': e
      });
    }
  },

  //User Sigin
  signin: (req, res) => {
    try {
      req.checkBody({
        'username': {
          notEmpty: true,
          isLength: {
            options: [{ min: 5, max: 100 }],
            errorMessage: 'Username must be within 5-13 characters'
          },
          errorMessage: 'Enter name'
        },
        'password': {
          notEmpty: true,
          errorMessage: 'Please fill Password'
        },
        'deviceId': {
          notEmpty: true,
          errorMessage: 'Please send device id'
        },
      });

      var errors = req.validationErrors();
      if (errors) {
        var errorsMessage = [];
        errors.forEach(function (err) {
          errorsMessage.push(err.msg);
        });

        res.json({
          "status": "error",
          "msg": errorsMessage[0]
        });
      } else {
        var isMatch = false;

        User.findOne({ useremail: req.body.username.toLowerCase(), active: "true" }, (err, user) => {
          if (err) {
            res.json({
              "status": "error",
              "msg": "error encountered"
            });
          }
          if (user !== null) {
            Async.waterfall([
              function (callback) {
                if (user.authorizationviauser.expireTime > Date.now() && user.authorizationviauser.active === true) {
                  isMatch = user.authorizationviauser.password == req.body.password ? true : false
                  callback(null, isMatch);
                } else {
                  user.comparePassword(req.body.password, async (err, isMatchPass) => {
                    callback(null, isMatchPass);
                  })
                }
              }
            ], function (err, isMatchAsync) {

              if (isMatchAsync) {

                //Enter in last login schema start
                const clientIp = requestIp.getClientIp(req);
                var user_id = mongoose.Types.ObjectId(user._id);
                UserLastLogin.findOne({ user_id: user_id }, function (err, data) {
                  if (err) {
                    console.log(err)
                  }
                  else {
                    if (data) {


                      data.ip_address = clientIp,
                        data.login_time = Date.now(),
                        data.login_via = req.headers['user-agent']

                      data.save((err, data) => {
                        //  console.log("Last Login updated", err)
                      });
                    }
                    else {
                      var user_last_login = new UserLastLogin({
                        ip_address: clientIp,
                        login_time: Date.now(),
                        user_id: user._id,
                        login_via: req.headers['user-agent']
                      })
                      user_last_login.save((err, data) => {
                        console.log("New Last Login saved", err)
                      });
                    }
                  }
                })

                var token = jwt.sign({
                  userId: user.user_id,
                  exp: moment.utc().add({ days: 1 }).unix(),
                }, process.env.JWT_SECRET);

                if ((user.token.jwttoken === null && user.token.deviceId === null && user.token.expireTime === null) || (user.token.deviceId === req.body.deviceId)) {
                  user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
                  user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
                  user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
                  user.save();
                  res.json({
                    "status": "success",
                    userinfo: {
                      avatar: user.avatar,
                      userId: user._id,
                      username: user.username,
                      avatarindex: user.avatarindex,
                      useremailverification: user.useremailverification,
                      token: user.token.jwttoken
                    }
                  })
                } else if (user.token.jwttoken !== null && user.token.deviceId !== req.body.deviceId && user.token.expireTime !== null) {
                  // Here is second login from another device
                  user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
                  user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
                  user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
                  user.save();
                  res.json({
                    "status": "success",
                    userinfo: {
                      avatar: user.avatar,
                      userId: user._id,
                      username: user.username,
                      avatarindex: user.avatarindex,
                      useremailverification: user.useremailverification,
                      token: user.token.jwttoken
                    }
                  })

                }
              } else {
                return res.json({
                  "status": "error",
                  "msg": "Invalid Password/Email"
                });
              }

            });
          } else {
            res.json({
              "status": "error",
              "msg": "user not found"
            });
          }
        })
      }
    } catch (err) {
      res.json({
        "status": "error",
        "msg": "error encountered"
      });
    }
  },

  //google Signin
  googleSignin: async (req, res) => {
    //Verify Google Token Here
    userDetails = await util.varifyGoogleToken(req);
    if (!userDetails)
      return res.status(401).json({ "status": "error", "message": "Invalid token" })
    //Check email address in our db
    user = await util.checkUserByEmail(userDetails.email);
    if (!user) {
      //register here
      var verifyemailtoken = randomstring.generate(64);
      var verifyemailtokenexpiry = Date.now() + 1800000;       //30 minutes
      var UUID = uuidv1();
      var register = new User({
        'user_id': UUID,
        'name': userDetails.name.toLowerCase(),
        'displayname': userDetails.name,
        'username': "",
        'displayusername': userDetails.name,
        'useremail': userDetails.email.toLowerCase(),
        'verifyemailtoken': verifyemailtoken,
        'verifyemailtokenexpiry': verifyemailtokenexpiry,
        'mobilenumber': "",
        'avatar': userDetails.picture,
        "useremailverification": true,
        'password': "",
        'created': Date.now()
      });
      register.save((err, user) => {
        if (err) {
          res.json({
            'status': 'error',
            'msg': 'error encountered'
          });
        } else {
          //login after register
          const clientIp = requestIp.getClientIp(req);
          var user_id = mongoose.Types.ObjectId(user._id);
          UserLastLogin.findOne({ user_id: user_id }, function (err, data) {
            if (err) {
              console.log(err)
            }
            else {
              if (data) {


                data.ip_address = clientIp,
                  data.login_time = Date.now(),
                  data.login_via = req.headers['user-agent']

                data.save((err, data) => {
                  //  console.log("Last Login updated", err)
                });
              }
              else {
                var user_last_login = new UserLastLogin({
                  ip_address: clientIp,
                  login_time: Date.now(),
                  user_id: user._id,
                  login_via: req.headers['user-agent']
                })
                user_last_login.save((err, data) => {
                  console.log("New Last Login saved", err)
                });
              }
            }
          })

          var token = jwt.sign({
            userId: user.user_id,
            exp: moment.utc().add({ days: 1 }).unix(),
          }, process.env.JWT_SECRET);

          if ((user.token.jwttoken === null && user.token.deviceId === null && user.token.expireTime === null) || (user.token.deviceId === req.body.deviceId)) {
            user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
            user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
            user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
            user.save();
            res.json({
              "status": "success",
              userinfo: {
                avatar: user.avatar,
                userId: user._id,
                username: user.username,
                avatarindex: user.avatarindex,
                useremailverification: user.useremailverification,
                token: user.token.jwttoken
              }
            })
          } else if (user.token.jwttoken !== null && user.token.deviceId !== req.body.deviceId && user.token.expireTime !== null) {
            // Here is second login from another device
            user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
            user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
            user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
            user.save();
            res.json({
              "status": "success",
              userinfo: {
                avatar: user.avatar,
                userId: user._id,
                username: user.username,
                avatarindex: user.avatarindex,
                useremailverification: user.useremailverification,
                token: user.token.jwttoken
              }
            })

          }

        }
      });
    }
    else {
      //login after register
      const clientIp = requestIp.getClientIp(req);
      var user_id = mongoose.Types.ObjectId(user._id);
      UserLastLogin.findOne({ user_id: user_id }, function (err, data) {
        if (err) {
          console.log(err)
        }
        else {
          if (data) {


            data.ip_address = clientIp;
            data.login_time = Date.now();
            data.login_via = req.headers['user-agent'];
            data.save((err, data) => {
              //  console.log("Last Login updated", err)
            });
          }
          else {
            var user_last_login = new UserLastLogin({
              ip_address: clientIp,
              login_time: Date.now(),
              user_id: user._id,
              login_via: req.headers['user-agent']
            })
            user_last_login.save((err, data) => {
              console.log("New Last Login saved", err)
            });
          }
        }
      })

      var token = jwt.sign({
        userId: user.user_id,
        exp: moment.utc().add({ days: 1 }).unix(),
      }, process.env.JWT_SECRET);

      if ((user.token.jwttoken === null && user.token.deviceId === null && user.token.expireTime === null) || (user.token.deviceId === req.body.deviceId)) {
        user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
        user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
        user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
        user.save();
        res.json({
          "status": "success",
          userinfo: {
            avatar: user.avatar,
            userId: user._id,
            username: user.username,
            avatarindex: user.avatarindex,
            useremailverification: user.useremailverification,
            token: user.token.jwttoken
          }
        })
      } else if (user.token.jwttoken !== null && user.token.deviceId !== req.body.deviceId && user.token.expireTime !== null) {
        // Here is second login from another device
        user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
        user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
        user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
        user.save();
        res.json({
          "status": "success",
          userinfo: {
            avatar: user.avatar,
            userId: user._id,
            username: user.username,
            avatarindex: user.avatarindex,
            useremailverification: user.useremailverification,
            token: user.token.jwttoken
          }
        })

      }



    }


  },

  //Facebook Signin
  facebookSign: async (req, res) => {
    //Verify Google Token Here
    userDetails = await util.verifyFacebookToken(req.body.token);

    if (userDetails.error)
      return res.json({ "status": "error", "message": "Invalid token" })

    //Check email address 
    user = await util.checkUserByEmail(userDetails.email);
    if (!user) {
      console.log("Register then Login")
      //register here
      var verifyemailtoken = randomstring.generate(64);
      var verifyemailtokenexpiry = Date.now() + 1800000;       //30 minutes
      var UUID = uuidv1();
      var register = new User({
        'user_id': UUID,
        'name': userDetails.name.toLowerCase(),
        'displayname': userDetails.name,
        'username': "",
        'displayusername': userDetails.name,
        'useremail': userDetails.email.toLowerCase(),
        'verifyemailtoken': verifyemailtoken,
        'verifyemailtokenexpiry': verifyemailtokenexpiry,
        'mobilenumber': "",
        "useremailverification": true,
        'password': "",
        'avatar': userDetails.picture.data.url,
        'created': Date.now()
      });
      register.save((err, user) => {
        if (err) {
          res.json({
            'status': 'error',
            'msg': 'error encountered'
          });
        } else {
          //login after register
          const clientIp = requestIp.getClientIp(req);
          var user_id = mongoose.Types.ObjectId(user._id);
          UserLastLogin.findOne({ user_id: user_id }, function (err, data) {
            if (err) {
              console.log(err)
            }
            else {
              if (data) {


                data.ip_address = clientIp,
                  data.login_time = Date.now(),
                  data.login_via = req.headers['user-agent']

                data.save((err, data) => {
                  //  console.log("Last Login updated", err)
                });
              }
              else {
                var user_last_login = new UserLastLogin({
                  ip_address: clientIp,
                  login_time: Date.now(),
                  user_id: user._id,
                  login_via: req.headers['user-agent']
                })
                user_last_login.save((err, data) => {
                  console.log("New Last Login saved", err)
                });
              }
            }
          })

          var token = jwt.sign({
            userId: user.user_id,
            exp: moment.utc().add({ days: 1 }).unix(),
          }, process.env.JWT_SECRET);

          if ((user.token.jwttoken === null && user.token.deviceId === null && user.token.expireTime === null) || (user.token.deviceId === req.body.deviceId)) {
            user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
            user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
            user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
            user.save();
            res.json({
              "status": "success",
              userinfo: {
                avatar: user.avatar,
                userId: user._id,
                username: user.username,
                avatarindex: user.avatarindex,
                useremailverification: user.useremailverification,
                token: user.token.jwttoken
              }
            })
          } else if (user.token.jwttoken !== null && user.token.deviceId !== req.body.deviceId && user.token.expireTime !== null) {
            // Here is second login from another device
            user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
            user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
            user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
            user.save();
            res.json({
              "status": "success",
              userinfo: {
                avatar: user.avatar,
                userId: user._id,
                username: user.username,
                avatarindex: user.avatarindex,
                useremailverification: user.useremailverification,
                token: user.token.jwttoken
              }
            })

          }

        }
      });
    }
    else {
      console.log("already this user")
      //login after register
      const clientIp = requestIp.getClientIp(req);
      var user_id = mongoose.Types.ObjectId(user._id);
      UserLastLogin.findOne({ user_id: user_id }, function (err, data) {
        if (err) {
          console.log(err)
        }
        else {
          if (data) {


            data.ip_address = clientIp,
              data.login_time = Date.now(),
              data.login_via = req.headers['user-agent']

            data.save((err, data) => {
              //  console.log("Last Login updated", err)
            });
          }
          else {
            var user_last_login = new UserLastLogin({
              ip_address: clientIp,
              login_time: Date.now(),
              user_id: user._id,
              login_via: req.headers['user-agent']
            })
            user_last_login.save((err, data) => {
              console.log("New Last Login saved", err)
            });
          }
        }
      })

      var token = jwt.sign({
        userId: user.user_id,
        exp: moment.utc().add({ days: 1 }).unix(),
      }, process.env.JWT_SECRET);

      if ((user.token.jwttoken === null && user.token.deviceId === null && user.token.expireTime === null) || (user.token.deviceId === req.body.deviceId)) {
        user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
        user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
        user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
        user.save();
        res.json({
          "status": "success",
          userinfo: {
            avatar: user.avatar,
            userId: user._id,
            username: user.username,
            avatarindex: user.avatarindex,
            useremailverification: user.useremailverification,
            token: user.token.jwttoken
          }
        })
      } else if (user.token.jwttoken !== null && user.token.deviceId !== req.body.deviceId && user.token.expireTime !== null) {
        // Here is second login from another device
        user.token.deviceId = user.token.deviceId === null ? req.body.deviceId : user.token.deviceId;
        user.token.jwttoken = (user.token.jwttoken === null) || (user.token.expireTime < Date.now()) ? token : user.token.jwttoken;
        user.token.expireTime = user.token.expireTime === null ? moment.utc().add({ days: 1 }).unix() : user.token.expireTime;
        user.save();
        res.json({
          "status": "success",
          userinfo: {
            avatar: user.avatar,
            userId: user._id,
            username: user.username,
            avatarindex: user.avatarindex,
            useremailverification: user.useremailverification,
            token: user.token.jwttoken
          }
        })

      }



    }


  },

  //Forgot Password (send token to user)
  forgotPassword: (req, res) => {
    const useremail = req.body.useremail;
    try {
      req.checkBody({
        'useremail': {
          notEmpty: true,
          errorMessage: 'Enter email id'
        },
      });

      const errors = req.validationErrors();
      if (errors) {
        var errorsMessage = [];
        errors.forEach(function (err) {
          errorsMessage.push(err.msg);
        });

        res.json({
          "status": "error",
          "msg": errorsMessage[0]
        });
      } else {
        User.findOne({ useremail: useremail }, (err, user) => {
          if (err) {
            res.json({
              "status": "error",
              "msg": "error encountered"
            });
          }
          if (!user) {
            res.json({
              "status": "error",
              "msg": "user does not exist"
            });
          } else {
            if (user.useremailverification === false) {
              return res.json({
                "status": "error",
                "msg": "please verify email first"
              });
            } else {
              const resetPasswordToken = randomstring.generate(100);
              const resetPasswordExpires = Date.now() + 600000; //10 min

              var mailOptions = {
                from: 'IGAMIO <me@samples.mailgun.org>',
                to: req.body.useremail,
                subject: 'Forgot Password | IGAMIO',
                html: `
                                <body>
                                    <h1>Hello ${user.username}</h1>
                                    <h2>Note: <b>Make sure the link is still valid as the link is only valid for 10 minutes</b></h2>
                                        <a title="Reset" href='${process.env.APP_DOMAIN}/verifyforgotpasswordlink/${resetPasswordToken}'>Click here to reset password token- ${resetPasswordToken} </a>
                                </body>      
                        `
              };

              mailgun.messages().send(mailOptions, function (error, body) {
                if (error) {
                  return res.json({
                    "status": "error",
                    "msg": error
                  })
                } else if (body.message === "Queued. Thank you.") {

                  user.resetpassexp = resetPasswordExpires;
                  user.resetpasstoken = resetPasswordToken;

                  user.save((err) => {
                    if (err) {
                      res.json({
                        "status": "error",
                        "msg": "error encountered"
                      });
                    } else {
                      res.json({
                        "status": "success",
                        "msg": "Activation Link sent to your email address",
                      })
                    }
                  });
                } else {
                  res.json({
                    "status": "error",
                    "msg": "Please Try to reset again"
                  })
                }
              });
            }
          }
        })
      }
    } catch (error) {
      res.json({
        "status": "error",
        "msg": "error encountered"
      });
    }
  },

  //Forgot Password (Verify Email Link)
  verifyForgotPassword: (req, res) => {
    var email_token = req.body.token;
    var password = req.body.password;
    var confirmpasword = req.body.confirmpasword;

    try {
      if (!password || !confirmpasword) {
        return res.status(401).json({ "status": "error", "message": "Please Enter Password & Confirm Password" });
      } else if (password !== confirmpasword) {
        return res.status(401).json({ "status": "error", "message": "Password & Confirm Password should be Same" });
      } else if (!email_token) {
        return res.status(401).json({ "status": "error", "message": "Token Not Found" });
      }
      else if (password.length < 6) {
        return res.status(401).json({ "status": "error", "message": "Passowrd Length Sould be minimum 6 " });
      } else {
        User.findOne({ resetpasstoken: email_token }, (err, user) => {
          if (err) {
            return res.status(401).json({ "status": "error", "message": "Something went wrong!" });
          }
          if (!user) {
            return res.status(401).json({ "status": "error", "message": "User Not Found" });

          } else {
            if (user.resetpassexp < Date.now() || user.resetpassexp == null) {
              return res.status(401).json({ "status": "error", "message": "Token Expired! Please do forgot password again!" });
            } else {
              user.password = password;
              user.resetpassexp = null;
              user.resetpasstoken = null;

              user.save((err) => {
                if (err) {
                  return res.status(401).json({ "status": "error", "message": "Something went wrong!" });
                } else {
                  return res.status(401).json({ "status": "error", "message": "Password Reset Successfully" });
                }
              });

            }
          }
        })
      }
    } catch (e) {
      return res.status(401).json({ "status": "error", "message": e });
    }
  },

  //Change Password
  changePassword: (req, res) => {
    const oldpassword = req.body.oldpassword;
    const newpassword = req.body.newpassword;
    const confirmnewpassword = req.body.confirmnewpassword;
    try {
      req.checkBody({
        'oldpassword': {
          notEmpty: true,
          errorMessage: 'Please enter current password'
        },
        'newpassword': {
          notEmpty: true,
          errorMessage: 'Please enter new password'
        },
        'confirmnewpassword': {
          notEmpty: true,
          errorMessage: 'Please enter confirmnewpassword'
        }

      });

      const errors = req.validationErrors();
      if (newpassword.length < 6) {
        return res.status(402).json({ "status": "error", "message": "password minimum length should be 6" })
      }
      if (errors) {
        var errorsMessage = [];
        errors.forEach(function (err) {
          errorsMessage.push(err.msg);
        });
        res.json({
          "status": "error",
          "msg": errorsMessage[0]
        });
      } else {
        User.findOne({ user_id: req.user.user_id }, (err, user) => {

          if (err) {
            return res.status(402).json({ "status": "error", "message": "Something went wrong" })
          }

          user.comparePassword(oldpassword, async (err, isMatch) => {
            if (isMatch) {
              user.comparePassword(req.body.newpassword, async (err, isMatch) => {
                //console.log('CHECK PASSWORD COMPARE TRUE OR NO', typeof isMatch, isMatch)
                if (isMatch) {
                  return res.json({
                    "status": "error",
                    "msg": "New password should not be the same as your old password"
                  });
                }
                if (newpassword !== confirmnewpassword) {
                  res.json({
                    "status": "error",
                    "msg": "Those password didn't match. Try again"
                  });
                } else {
                  user.password = newpassword;
                  user.save(function (error, saved) {
                    if (error) {
                      res.json({
                        "status": "error",
                        "msg": "Error while saving new password"
                      });
                    } else {
                      res.json({
                        "status": "success",
                        "msg": "Password successfully changed"
                      });
                    }
                  })
                }
              })
            } else {
              res.json({
                "status": "error",
                "msg": "Old password is wrong"
              });
            }
          })
        });
      }
    } catch (error) {
      res.json({
        "status": "error",
        "msg": "error encountered"
      });
    }
  },

  //Email Verification
  emailVerfication: (req, res) => {
    const Token = req.body.token;

    try {
      if (!Token)
        return res.json({
          "status": "error",
          "msg": "Token not found"
        });

      User.findOne({ verifyemailtoken: Token }, function (err, user) {

        if (err) {
          return res.json({
            "status": false,
            "msg": "error encountered"
          });
        }
        if (user.useremailverification) {
          return res.status(402).json({ "status": "error", "message": "Email Already Verified!" })
        }
        if (user.verifyemailtokenexpiry < Date.now() || user.verifyemailtokenexpiry == null || user.verifyemailtokenexpiry == '') {
          user.useremailverification = true;
          user.verifyemailtokenexpiry = null;

          user.save();
          return res.status(402).json({ "status": "error", "message": "Email Expired" })
        } else {
          user.useremailverification = true;

          user.verifyemailtokenexpiry = null;

          user.save(function (err, saved) {
            if (err) {
              return res.json({
                "status": false,
                "msg": "error encountered"
              });
            }
            if (!saved) {
              return res.json({
                "status": "error",
                "msg": "Error occurred while saving user after verifying email. Please try again"
              });
            }
            return res.status(200).json({ "status": "error", "message": "Email Verified Successfully!" })
          });
        }
      })

    } catch (error) {
      res.json({
        "status": "error",
        "msg": "error encountered"
      });
    }
  },

  //Send Text Message
  sendTextMessage: async (req, res) => {
    var textMessageStatus = await util.sendTextMessage("918109299136", "OTP is 1234");
    console.log("message status", textMessageStatus);
  }


};

//