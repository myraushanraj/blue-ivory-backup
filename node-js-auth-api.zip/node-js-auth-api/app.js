require('dotenv').config();
require('./database/connection');
var createError = require('http-errors');
var express = require('express');
var app = express();
var expressValidator = require('express-validator');
app.use(expressValidator());

var morgan = require('morgan');
var fs = require('fs');
var path = require('path');


//Route File
var apiRouter = require('./routes/routeAuth');

//parsing the body of incoming HTTP requests
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//Morgan for logger (Every request save in access.log file)

var accessLogStream = fs.createWriteStream(path.join(__dirname, 'logs/access.log'), { flags: 'a' });
app.use(morgan('combined', { stream: accessLogStream }));
//error log
app.use(morgan('combined', { skip: function (req, res) { return res.statusCode < 600 }, stream: __dirname + 'logs/default.log' }));


// api routes
app.use('/auth', apiRouter);


// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});


module.exports = app;
