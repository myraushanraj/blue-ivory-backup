const request = require('supertest')
const app = require('../app')
describe('Post Endpoints', () => {

    //Register 
    it('should create a new post', async () => {
        const res = await request(app)
            .post('/auth/register')
            .send({
                "name": "raushan raj",
                "useremail": "raushan10695@gmail.com",
                "mobilenumber": "8109299136",
                "username": "raushan",
                "password": "123456",
                "confirmpassword": "123456",
                "referral_code": "raushan1"
            })
        console.log("Actual Status Code : ", res.statusCode)
        expect(res.statusCode).toEqual(200)
    })

    //Login
    it('should create a new post', async () => {
        const res = await request(app)
            .post('/auth/register')
            .send({
                "useremail": "raushan10695@gmail.com",
                "password": "123456",
            })
        expect(res.statusCode).toEqual(200)

    })

    //User Wallet

})