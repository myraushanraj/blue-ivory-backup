const Wallet = require('../models/wallet');
const Transactionhistory = require('../models/transactionHistory');
const promocodeUtil = require("./common/walletHelper");
var mongoose = require('mongoose');

module.exports = {
    //Get user wallet
    wallet: (req, res) => {
        Wallet.findOne({ user_id: mongoose.Types.ObjectId(req.user._id) }).populate('user_id').then((data) => {
            res.status(200).json({ "status": "success", "message": data });
        })
    },
    //Create New promocode
    createPromoCode: async (req, res) => {
        var promocode = await promocodeUtil.createPromocode("signup", "IGAMIO", 50, 1581593227002, Date.now());


    },
    //Get User Transaction History
    Transactionhistory: (req, res) => {
        Transactionhistory.find({ user_id: mongoose.Types.ObjectId(req.user._id) }, (err, data) => {
            res.status(200).json({ "status": "success", "message": data });
        }).sort({ created: -1 });
    },

}