const util = require('./common/authHelper');
module.exports = {
    //Get match board
    matchBoard: async (req, res) => {

        var matchToken = await util.matchToken();
        console.log(matchToken)
        var matchBoardEndPoint = `coverage/?access_token=${matchToken}`;
        var matchBoard = await util.matchGetRequest(matchBoardEndPoint);
        if (matchBoard.status_code == 200)
            res.status(200).json({ 'status': 'success', 'data': matchBoard.data })
        else
            res.status(402).json({ 'status': 'false', 'data': "Something went wrong!" })
    },

    //Get Match List
    matchList: async (req, res) => {
        var matchToken = await util.matchToken();
        var boardKey = req.body.boardid;
        //we can pass date also
        var matchBoardSchedule = `board/${boardKey}/schedule/?access_token=${matchToken}&month=2020-01`;
        var matchBoardSchedule = await util.matchGetRequest(matchBoardSchedule);
        console.log(matchBoardSchedule.data.seasons.length);
        if (matchBoardSchedule.status_code == 200 && matchBoardSchedule.data.seasons.length > 0) {
            var allMatchData = [];
            for (var i = 0; i < matchBoardSchedule.data.seasons.length; i++) {
                console.log("getting data for seasons ", matchBoardSchedule.data.seasons[i].key);
                var allMatchEndpoint = `season/${matchBoardSchedule.data.seasons[i].key}/schedule/?access_token=${matchToken}`;
                var allMatch = await util.matchGetRequest(allMatchEndpoint);
                // allMatchData=allMatch.data;
                allMatchData.push(allMatch.data);

            }



            res.status(200).json({ 'status': 'success', 'data': allMatchData });
        }

        else
            res.status(402).json({ 'status': 'false', 'data': "No Match Available" });
    },

}