const { OAuth2Client } = require('google-auth-library');
const client = new OAuth2Client("739472579341-fas37tg12pegg1l1hpa7timu0pus2ntt.apps.googleusercontent.com");
var User = require('../../models/user');
const fetch = require('node-fetch');
var mailgun = require('mailgun-js')({ apiKey: process.env.mailgunApIKey, domain: process.env.mailgunDomain });
const Nexmo = require('nexmo');

module.exports = {

    //Verify Google Access Token
    varifyGoogleToken: (req, res) => {
        var token = req.body.token;
        async function verify() {
            const ticket = await client.verifyIdToken({
                idToken: token
            });
            const payload = ticket.getPayload();
            const userid = payload['sub'];
            return payload;
        }
        return verify().catch(console.error);
    },

    //Verify Facebook Access Token
    verifyFacebookToken: (accessToken) => {
        return new Promise(function (resolve, reject) {
            fetch(`https://graph.facebook.com/me?fields=id,name,email,picture.type(large)&access_token=${accessToken}`)
                .then(res => res.json())
                .then(json => resolve(json));
        })

    },

    //Get User By Email
    checkUserByEmail: (email) => {
        return new Promise(function (resolve, reject) {
            User.findOne({ useremail: email }).then((data) => {
                resolve(data)
            })
        })

    },

    //Send Email To User
    sendEmail: (mailOptions) => {

        return new Promise((resolve, reject) => {

            mailgun.messages().send(mailOptions, function (error, body) {
                if (error) {
                    resolve("Email not sent");
                } else if (body.message === "Queued. Thank you.") {
                    resolve("Email Sent Successfully")

                } else {
                    console.log("Email Sent TO User");
                }
            })

        })

    },

    //Send Text Message To User
    sendTextMessage: (to, text) => {
        return new Promise((resolve, reject) => {
            const nexmo = new Nexmo({
                apiKey: 'b9d45235',
                apiSecret: 'WUHPf43u7gd1gXyZ',
            });


            nexmo.message.sendSms("IGAMIO", to, text, (err, textMessageStatus) => {
                if (err)
                    console.log(err);
                resolve(textMessageStatus);
            });

        })
    },
    // post fetch start here
    post_data: async (post_data, end_point) => {

        const res = await fetch("https://api.pokernxt.in/api/" + end_point, {
            method: "POST",
            headers: { "Content-type": "application/json" },
            body: JSON.stringify(post_data)
        });
        return await res.json();

    },
    matchToken: async () => {

        var post_data = {
            "access_key": "d9eced93358af4f9836050f0053c927c",
            "secret_key": "34564f7709f06941c1b999d6b576f85d",
            "app_id": "com.cricpredict.www",
            "device_id": "developer"
        };

        const res = await fetch(`${process.env.matchapi}/auth`, {
            method: "POST",
            headers: { "Content-type": "application/json" },
            body: JSON.stringify(post_data)
        });

        var response = await res.json();

        return await response.auth.access_token;
    },
    matchGetRequest: async (endpoint) => {

        const res = await fetch(`${process.env.matchapi}/${endpoint}`, {
            method: "GET",
            headers: { "Content-type": "application/json" }
        });
        var response = await res.json();
        return await response;
    },

    //Get All Seasons Boardwise
    MatchSeason: async (endpoint) => {
        const res = await fetch(`${process.env.matchapi}/${endpoint}`, {
            method: "GET",
            headers: { "Content-type": "application/json" }
        });
        var response = await res.json();
        return await response;
    }

}