const Wallet = require("../../models/wallet");
const Promocode = require("../../models/PromoCode");
const TransactionHistory = require('../../models/transactionHistory');
var mongoose = require('mongoose');




module.exports = {
    //Create New Wallet For New User
    createWallet: async (user_id, bonus) => {
        //var user_id = mongoose.Types.ObjectId(user_id);
        return new Promise((resolve, reject) => {
            var walletModel = new Wallet({
                user_id: user_id,
                bonusbalance: bonus
            })
            walletModel.save((err, data) => {
                if (err)
                    reject(err)
                else
                    resolve(data);
            })
        })

    },
    //New Promocode
    createPromocode: async (promocode_type, promo_code, bonus, expiry) => {
        //var user_id = mongoose.Types.ObjectId(user_id);
        return new Promise((resolve, reject) => {
            var promoCodeModel = new Promocode({
                promocode_type: promocode_type,
                promo_code: promo_code,
                amount: bonus,
                expiry: expiry

            })
            promoCodeModel.save((err, data) => {
                if (err)
                    reject(err)
                else
                    resolve(data);
            })
        })

    },

    // Find Promocode Details With Promocode
    FIndPromoCode: async (promo_code) => {
        //var user_id = mongoose.Types.ObjectId(user_id);
        return new Promise((resolve, reject) => {
            Promocode.findOne({ promo_code: promo_code })
        })

    },

    //Wallet Transaction
    WalletTransaction: async (user_id, field, amount, transactionType, userUseReferral) => {
        console.log("user is-", user_id);
        var user_id = mongoose.Types.ObjectId(user_id);
        return new Promise((resolve, reject) => {
            mongoose.set('useFindAndModify', false);
            if (transactionType == "credit") {
                Wallet.findOneAndUpdate({ user_id: user_id }, { $inc: { bonusbalance: amount } }, (err, response) => {
                    if (err) {
                        resolve(err)
                    }
                    else {
                        // console.log("response", response);
                        // console.log("prevoious balance is: ", response.bonusbalance);

                        //  console.log("updated balance is: ", response.bonusbalance + amount);
                        //transaction history
                        var transaction = new TransactionHistory({
                            user_id: user_id,
                            amount: amount,
                            transaction_type: transactionType,
                            transaction_by: "Referral bonus",
                            updated_bonus: response.bonusbalance + amount,
                            updated_main: response.mainbalance,
                            updated_secondary: response.secondarybalnce,
                            transaction_details: "referral bonus of " + userUseReferral

                        })
                        transaction.save(async (err, data) => {
                            if (err) {
                                console.log(err);
                            }
                            // console.log("transaction response", data);
                            resolve(response);
                        })
                    }
                })
            }
            else {

            }

        })

    },


}