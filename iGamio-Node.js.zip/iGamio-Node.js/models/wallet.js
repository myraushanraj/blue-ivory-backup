var mongoose = require('mongoose');
const ObjectId = mongoose.Schema.Types.ObjectId;
const User = require('./user')

// define the schema for userwallet
var WalletSchema = new mongoose.Schema({

    "user_id": {
        type: ObjectId,
        ref: 'User'
    },
    "mainbalance": {
        type: Number,
        default: 0
    },
    "secondarybalnce": {
        type: Number,
        default: 0
    },
    "bonusbalance": {
        type: Number,
        default: 0
    },
    "created": {
        type: Number,
        default: Date.now()
    }
},
    {
        timestamps: true
    });

module.exports = mongoose.model('Wallet', WalletSchema);