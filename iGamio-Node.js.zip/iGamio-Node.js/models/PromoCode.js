var mongoose = require('mongoose');


// define the schema for usedPromo
var PromoCodeSchema = new mongoose.Schema({
    "promocode_type": {
        type: String,
        required: true
    },
    "promo_code": {
        type: String,
        required: true
    },
    "amount": {
        type: Number,
        required: true,
    },
    "expiry": {
        type: Number,
        required: true
    },
    "created": {
        type: Number,
        default: Date.now()
    }
},
    {
        timestamps: true
    }
);

module.exports = mongoose.model('PromoCode', PromoCodeSchema);