var mongoose = require('mongoose');

// define the schema for all Match list
var listmatch = new mongoose.Schema({


    "name": {
        type: String,
        default: null
    },
    "short_name": {
        type: String,
        default: null
    },
    "season": {
        type: String,
        default: null
    },
    "title": {
        type: String,
        default: null
    },
    "format": {
        type: String,
        default: null
    },
    "team1": {
        type: String,
        default: null
    },
    "team2": {
        type: String,
        default: null
    },
    "team1display": {
        type: String,
        default: null
    },
    "team2display": {
        type: String,
        default: null
    },
    "matchkey": {
        type: String,
        default: null
    },
    "series": {
        type: String,
        default: null
    },
    "start_date": {
        type: Date,
        default: null
    },
    "end_date": {
        type: String,
        default: null
    },
    "status": {
        type: String,
        default: null
    },
    "launch_status": {
        type: String,
        default: null
    },
    "final_status": {
        type: String,
        default: null
    },
    "refund": {
        type: Date,
        default: null
    },
    "winner_team": {
        type: String,
        default: null
    },
    "created_at": {
        type: Date,
        default: Date.now()
    }

},
    {
        timestamps: true
    });

module.exports = mongoose.model('listmatch', listmatch);