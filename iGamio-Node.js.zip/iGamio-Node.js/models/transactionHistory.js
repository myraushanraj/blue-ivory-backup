var mongoose = require('mongoose');
const ObjectId = mongoose.Schema.Types.ObjectId;

var TransactionHistorySchema = new mongoose.Schema({

    "user_id": {
        type: ObjectId,
        ref: 'User'
    },

    "amount": {
        type: Number,
    },

    "transaction_type": {
        type: String,
        required: true
    },

    "transaction_by": {
        type: String,
    },

    "promocode_id": {
        type: ObjectId,
        ref: 'PromoCode',
        default: null
    },
    "updated_bonus": {
        type: Number,
        required: true
    },
    "updated_main": {
        type: Number,
        required: true
    },
    "updated_secondary": {
        type: Number,
        required: true
    },
    "transaction_details": {
        type: String,
        default: null
    },

    "created": {
        type: Number,
        default: Date.now()
    },

},
    {
        timestamps: true
    });

module.exports = mongoose.model('TransactionHistory', TransactionHistorySchema);