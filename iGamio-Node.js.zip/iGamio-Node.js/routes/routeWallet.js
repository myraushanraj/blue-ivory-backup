const express = require('express');
const router = express.Router();
const isAuthenticated = require('../middlewares/authorization');
const wallet = require('../controllers/walletController');
var isAdmin = require('../middlewares/admin');

router.get('/create-promocode', isAuthenticated, isAdmin, wallet.createPromoCode);
router.get('/user-wallet', isAuthenticated, wallet.wallet);
router.get('/user-transaction', isAuthenticated, wallet.Transactionhistory);

module.exports = router;