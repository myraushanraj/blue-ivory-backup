const express = require('express');
const router = express.Router();
const match = require('../controllers/matchController');

router.get('/match-board', match.matchBoard);
router.post('/match-list', match.matchList);

module.exports = router;