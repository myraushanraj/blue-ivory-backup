const admin = (req, res, next) => {
    if (req.user.userrole !== "admin") {
        return res.status(401).json({ "status": "error", "message": "You haven't permission!" })
    }
    else {
        next();
    }
}

module.exports = admin;